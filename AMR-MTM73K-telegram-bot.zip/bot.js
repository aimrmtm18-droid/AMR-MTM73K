require("dotenv").config();
const TelegramBot = require("node-telegram-bot-api");

const token = process.env.BOT_TOKEN;
const webAppUrl = process.env.WEB_APP_URL;

if (!token || !webAppUrl) {
  console.error("Configure BOT_TOKEN and WEB_APP_URL in your .env file.");
  process.exit(1);
}
if (!webAppUrl.startsWith("https://")) {
  console.error("Telegram Mini Apps require a public HTTPS URL.");
  process.exit(1);
}

const bot = new TelegramBot(token, { polling: true });

bot.onText(/^\/start(?:@\w+)?$/, async (msg) => {
  const chatId = msg.chat.id;
  await bot.sendMessage(chatId, "Bienvenue 👋", {
    reply_markup: {
      inline_keyboard: [[
        { text: "🚀 Ouvrir AMR-MTM73K", web_app: { url: webAppUrl } }
      ]]
    }
  });
});

bot.on("polling_error", (err) => console.error("Polling error:", err.message));
console.log("AMR-MTM73K bot is running.");
