# AMR-MTM73K — bot Telegram + Mini App

## Ce que fait cette première version
- `/start` envoie un bouton pour ouvrir la Mini App Telegram.
- La Mini App affiche **AMR-MTM73K**, le drapeau palestinien avec une animation d'apparition, et une icône Snapchat stylisée.
- Interface responsive pour mobile, avec animations légères.

## Installation
1. Installe Node.js (version récente).
2. Crée un bot avec **@BotFather** sur Telegram et récupère son token.
3. Copie `.env.example` vers `.env`, puis renseigne `BOT_TOKEN` et `WEB_APP_URL`.
4. Héberge le dossier `web/` sur un hébergement public en **HTTPS** (par exemple un hébergement statique).
5. Dans `.env`, mets l'URL HTTPS exacte de la page hébergée.
6. Dans ce dossier, lance :
   ```bash
   npm install
   npm start
   ```
7. Ouvre ton bot Telegram et envoie `/start`.

## Important
- Ne partage jamais ton token BotFather. Si tu l'as publié, régénère-le avec BotFather.
- Le bouton ouvre une Mini App Telegram. Telegram exige une URL HTTPS publique : le fichier `index.html` sur ton téléphone ou `localhost` ne suffit pas.
- Cette base n'envoie aucune donnée personnelle et ne fait aucune recherche sur les utilisateurs.
