const tg = window.Telegram?.WebApp;
if (tg) {
  tg.ready();
  tg.expand();
  tg.setHeaderColor?.("#090b12");
  tg.setBackgroundColor?.("#090b12");
}